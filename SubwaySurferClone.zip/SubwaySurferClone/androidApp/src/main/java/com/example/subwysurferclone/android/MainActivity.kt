package com.example.subwysurferclone.android
// normal way
//import android.content.Context
//import android.content.Intent
//import android.os.Bundle
//import android.widget.Button
//import androidx.appcompat.app.AppCompatActivity
//import com.example.subwysurferclone.shared.GameActivity
//
//
//class MainActivity : AppCompatActivity() {
//    private lateinit var startButton: Button
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//        startButton = findViewById(R.id.startButton)
//
//        startButton.setOnClickListener {
//            val intent=Intent(this, GameActivity::class.java)
//            startActivity(intent)
//         //   overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
//            finish()
//        }
//    }
//}
//
//
//
//
//
//
//
//
//
// src/androidMain/kotlin/CustomKorgeActivity.kt


//korge
import android.os.Bundle
import com.example.subwaysurferclone.shared.SubwaySurferCloneScene



import korlibs.image.color.*
import korlibs.korge.*
import korlibs.korge.scene.sceneContainer
import korlibs.math.geom.*
import korlibs.render.KorgwActivity

class MainActivity : KorgwActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override suspend fun activityMain() {
        Korge(
            title = "Subway Surfer",
            windowSize = Size(480, 800),
            virtualSize = Size(480,800),
           backgroundColor = Colors.TRANSPARENT,


        ) {
            sceneContainer().changeTo({ SubwaySurferCloneScene() })
        }
    }
}

