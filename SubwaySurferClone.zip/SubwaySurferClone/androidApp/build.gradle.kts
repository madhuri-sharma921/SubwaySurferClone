import org.gradle.internal.impldep.org.junit.experimental.categories.Categories.CategoryFilter.exclude

plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.compose.compiler)

}

android {
    namespace = "com.example.subwysurferclone.android"
    compileSdk = 35
    sourceSets {
        getByName("main") {
            assets.srcDirs("src/main/assets")
            res.srcDirs("src/main/res")
            manifest.srcFile("src/main/AndroidManifest.xml")
        }
    }
    defaultConfig {
        applicationId = "com.example.subwysurferclone.android"
        minSdk = 21
        //noinspection OldTargetApi
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
        viewBinding = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
      jvmTarget = "1.8"

    }

}

dependencies {

    implementation (libs.androidx.activity.compose.v180)
    implementation (libs.androidx.ui.v154)
    implementation (libs.androidx.foundation.v154)
    // Korge Game Engine
    implementation(libs.com.soywiz.korge.korge2)
    implementation(libs.soywiz.korge.android)
 // implementation(libs.soywiz.korge.core)
    // Android Core
    implementation(libs.androidx.core.ktx.v1120)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.ktx)

    // Layout
    implementation(libs.androidx.constraintlayout.v214)
    implementation(libs.kotlin.stdlib.v190)
    implementation (libs.androidx.activity.compose.v180)
    implementation (libs.androidx.ui.v154)
    implementation (libs.androidx.foundation.v154)
    // Jetpack Compose
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.androidx.activity.compose)
    debugImplementation(libs.compose.ui.tooling)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

      // Korge engine

    // Project Module
    implementation(project(":shared"))

    // Duplicate Korge dependencies (consider removing one)
//    implementation(libs.github.korge)
//    implementation(libs.github.korge.android)
}