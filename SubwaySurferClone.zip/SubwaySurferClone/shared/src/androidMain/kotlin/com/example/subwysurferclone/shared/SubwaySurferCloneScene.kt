package com.example.subwaysurferclone.shared


import korlibs.event.Key
import korlibs.korge.scene.Scene
import korlibs.korge.view.*
import korlibs.korge.input.*
import korlibs.image.bitmap.Bitmap
import korlibs.image.bitmap.Bitmap32
import korlibs.image.color.Colors
import korlibs.image.format.readBitmap
import korlibs.io.async.launch
import korlibs.io.async.launchImmediately
import korlibs.io.file.std.resourcesVfs
import korlibs.korge.scene.sceneContainer
import korlibs.korge.tween.*
import korlibs.korge.view.align.centerOn
import korlibs.korge.view.align.centerXOn
import korlibs.math.geom.Anchor
import korlibs.math.interpolation.Easing
import korlibs.time.TimeSpan
import korlibs.time.milliseconds
import korlibs.time.seconds
import kotlinx.coroutines.delay
import kotlin.random.Random
import kotlinx.atomicfu.atomic
import kotlin.math.sin

class SubwaySurferCloneScene : Scene() {
    // Game assets
    private var playerRunBitmap: Bitmap = Bitmap32(100, 100, Colors.BLUE)
    private var playerJumpBitmap: Bitmap = Bitmap32(100, 100, Colors.RED)
    private var obstacleBitmap: Bitmap = Bitmap32(100, 100, Colors.GREEN)
    private var backgroundBitmap: Bitmap = Bitmap32(2048, 1536, Colors.LIGHTBLUE)
    private val obstacles = mutableListOf<Image>()

    // Game objects
    private lateinit var player: Image
    private lateinit var scoreText: Text
    private lateinit var livesText: Text
    private var background1: Image? = null
    private var background2: Image? = null

    // Ground parameters
    private val groundLevel = 675.0

    // Game state
    private var score = 0
    private var lives = 3
    private val isGameOver = atomic(false)
    private var isJumping = false
    private var isOnGround = true
    private var playerDirection = 0

    // Jump physics parameters
    private var jumpVelocity = 0.0
    private val jumpStrength = -2000.0
    private val gravity = 5000.0

    // Game parameters
    private val backgroundSpeed = 4.0
    private val playerSpeed = 10.0
    private var obstacleSpeed = 6.0

    // Player starting position - EXACTLY at the left edge
    private val playerStartX = 20.0  // Very close to the left edge

    // Difficulty progression
    private val baseObstacleSpeed = 6.0
    private val speedIncreaseInterval = 500
    private val speedIncrement = 0.5

    // Track crossed obstacles
    private val crossedObstacles = mutableSetOf<Image>()

    // Containers
    private var gameContainer: Container? = null
    private var popupContainer: Container? = null

    override suspend fun SContainer.sceneMain() {
        resetGameState()
        gameContainer = container {
            loadResources()
            setupBackground()
            setupUI()
            setupPlayer()
            startGameLoop()
        }
        addUpdater { dt -> update(dt) }
        addUpdater{scoreText->score}
    }

    private fun resetGameState() {
        score = 0
        lives = 3
        obstacleSpeed = baseObstacleSpeed
        isGameOver.value = false
        isJumping = false
        isOnGround = true
        playerDirection = 0
        jumpVelocity = 0.0
        crossedObstacles.clear()
    }

    private suspend fun Container.loadResources() {
        try {
            playerRunBitmap = resourcesVfs["character.png"].readBitmap()
            playerJumpBitmap = resourcesVfs["character.png"].readBitmap()
            obstacleBitmap = resourcesVfs["coin.png"].readBitmap()
            backgroundBitmap = resourcesVfs["background.png"].readBitmap()
        } catch (e: Exception) {
            println("Using fallback bitmaps: ${e.message}")
        }
    }

    private fun Container.setupBackground() {
        background1 = image(backgroundBitmap) {
            size(views.virtualWidth, views.virtualHeight)
            position(0.0, 0.0)
        }
        background2 = image(backgroundBitmap) {
            size(views.virtualWidth, views.virtualHeight)
            position(views.virtualWidth.toDouble(), 0.0)
        }
    }

    private fun Container.setupPlayer() {
        player = image(playerRunBitmap) {
            anchor(Anchor.BOTTOM_LEFT)  // Anchor to bottom left
            position(playerStartX, groundLevel)  // Position at the left edge
            scale(0.25)

            keys {
                down(Key.SPACE) { initiateJump() }
                down(Key.UP) { initiateJump() }
            }

            onClick {
                initiateJump()
            }
        }

        // Print position to verify
        println("Player positioned at x=${player.x}, y=${player.y}")
    }

    private fun Container.setupUI() {
        scoreText = text("Score: $score", textSize = 32.0) {
            position(20.0, 20.0)
            color = Colors.WHITE
        }
        livesText = text("Lives: $lives | Speed: ${"%.1f".format(obstacleSpeed)}", textSize = 32.0) {
            position(20.0, 60.0)
            color = Colors.WHITE
        }
    }

    private fun Container.startGameLoop() {
        startBackgroundScroll()
        startObstacleSpawning()
    }

    private fun initiateJump() {
        if (!isGameOver.value && isOnGround && !isJumping) {
            isJumping = true
            isOnGround = false
            jumpVelocity = jumpStrength  // Set initial upward velocity



            launchImmediately {
                // Wait for the jump to complete
                while (isJumping) {
                    delay(16.milliseconds)
                }
                // Change back to running bitmap

            }
        }
    }

    fun update(dt: TimeSpan) {
        if (isGameOver.value) return

        // Handle jumping physics
        if (isJumping || !isOnGround) {
            // Apply gravity to jump velocity
            jumpVelocity += gravity * dt.seconds

            // Update player's vertical position based on jump velocity
            player.y += jumpVelocity * dt.seconds

            // Check if player has landed on the ground
            if (player.y >= groundLevel) {
                player.y = groundLevel
                isOnGround = true
                isJumping = false
                jumpVelocity = 0.0
            }
        }

        // Ensure player stays at fixed X position
        player.x = playerStartX

        // Update obstacles and check collisions/scoring
        updateObstacles(dt)
    }

    private fun updateObstacles(dt: TimeSpan) {
        val iterator = obstacles.iterator()
        while (iterator.hasNext()) {
            val obstacle = iterator.next()

            // Move obstacle
            obstacle.x -= obstacleSpeed * dt.seconds * 60

            // Remove obstacles that go off screen
            if (obstacle.x < -obstacle.width) {
                obstacle.removeFromParent()
                iterator.remove()
                continue
            }

            // Skip obstacles already scored
            if (obstacle in crossedObstacles) continue

            // Calculate if the obstacle is directly in front of or under the player
            val isObstacleInJumpZone = obstacle.x <= player.x + player.width &&
                    obstacle.x + obstacle.width >= player.x

            // Check if player successfully jumped over obstacle
            if (isJumping && isObstacleInJumpZone) {
                // Check if player's feet are above the obstacle
                if (player.y + player.height * 0.8 < obstacle.y) {
                    // Successfully jumped over obstacle
                    if (obstacle !in crossedObstacles) {
                        crossedObstacles.add(obstacle)
                        score += 20
                        scoreText.text = "Score: $score"
                    }
                }
            }

            // Check if player passed the obstacle (for scoring non-jumping passes)
            if (!isObstacleInJumpZone && obstacle.x + obstacle.width < player.x &&
                obstacle !in crossedObstacles) {
                crossedObstacles.add(obstacle)
                score += 20
                scoreText.text = "Score: $score"
            }

            // Check for collision - only with obstacles not yet crossed
            if (obstacle !in crossedObstacles && player.globalBounds.intersects(obstacle.globalBounds)) {
                lives--
                score+=10
                livesText.text = "Lives: $lives | Speed: ${"%.1f".format(obstacleSpeed)}"

                scoreText.text="Score: $score"
                // Flash the obstacle for visual feedback
                launchImmediately {
                    obstacle.alpha = 0.5
                    delay(200.milliseconds)
                    obstacle.alpha = 1.0
                }

                // Add to crossed obstacles to prevent multiple collisions
                crossedObstacles.add(obstacle)

                if (lives <= 0) {
                    isGameOver.value = true
                    showGameOver()
                }
            }
        }
    }

    private fun startBackgroundScroll() = launch {
        while (!isGameOver.value) {
            background1?.x = (background1?.x ?: 0.0) - backgroundSpeed
            background2?.x = (background2?.x ?: 0.0) - backgroundSpeed

            if ((background1?.x ?: 0.0) <= -views.virtualWidth) {
                background1?.x = views.virtualWidth.toDouble()
            }
            if ((background2?.x ?: 0.0) <= -views.virtualWidth) {
                background2?.x = views.virtualWidth.toDouble()
            }
            delay(16.milliseconds)
        }
    }

    private fun startObstacleSpawning() = launch {
        while (!isGameOver.value) {
            spawnObstacle()
            delay(Random.nextLong(1500, 2500))
        }
    }

    private fun spawnObstacle() = launch {
        // Calculate dynamic speed based on score
        obstacleSpeed = baseObstacleSpeed + (score / speedIncreaseInterval) * speedIncrement
        livesText.text = "Lives: $lives | Speed: ${"%.1f".format(obstacleSpeed)}"

        scoreText.text="Score: $score"
        // Create the obstacle at ground level
        val obstacle = gameContainer?.image(obstacleBitmap) {
            anchor(Anchor.BOTTOM_LEFT)
            position(
                views.virtualWidth.toDouble(),
                groundLevel // Align to the ground level
            )
            scale(0.22)
        } ?: return@launch

        obstacles.add(obstacle)
    }

    private fun showGameOver() {
        val currentStage = views.stage

        launchImmediately(views.coroutineContext) {
            popupContainer?.removeFromParent()

            popupContainer = Container().addTo(currentStage).apply {
                solidRect(views.virtualWidth, views.virtualHeight, Colors.BLACK.withAd(0.8))

                val gameOverText = text("GAME OVER", textSize = 64.0) {
                    centerXOn(this@apply)
                    y = views.virtualHeight * 0.3
                    color = Colors.RED
                }

                val scoreText = text("Score: $score", textSize = 48.0) {
                    centerXOn(this@apply)
                    y = gameOverText.y + gameOverText.textSize + 20
                    color = Colors.WHITE
                }

                val restartText = text("Tap to restart", textSize = 36.0) {
                    centerXOn(this@apply)
                    y = scoreText.y + scoreText.textSize + 40
                    color = Colors.YELLOW
                }

                onClick {
                    removeFromParent()
                    restartGame()
                }
            }
        }
    }

    private fun restartGame() {
        launchImmediately(views.coroutineContext) {
            // Complete scene teardown
            gameContainer?.removeFromParent()
            popupContainer?.removeFromParent()

            // Full game reset
            views.root?.sceneContainer()?.changeTo<SubwaySurferCloneScene>()
        }
    }
}