import org.gradle.kotlin.dsl.implementation

plugins {
    kotlin("multiplatform") version "2.0.21"
    id("com.android.library")


}



kotlin {

    androidTarget()

    sourceSets {
        val commonMain by getting {
            dependencies {


                // PNG support specifically

                // Korge Dependencies
              //  implementation ("com.soywiz.korlibs.korge:korge-android-compose:5.4.0")
                implementation(libs.com.soywiz.korge.korge2)
                implementation(libs.soywiz.korge.android)
        //       implementation (libs.soywiz.korge.core)
                // Kotlin Coroutines
                implementation(libs.kotlinx.coroutines.android.v173)
//                implementation(libs.github.korge)
//                implementation(libs.github.korge.android)
                implementation (libs.androidx.activity.compose.v180)
                implementation (libs.androidx.ui.v154)
                implementation (libs.androidx.foundation.v154)
                // AndroidX libraries
                implementation("androidx.core:core-ktx:1.15.0")
                implementation("androidx.activity:activity-ktx:1.10.1")
            }
        }

        val androidMain by getting {
            dependencies {

                implementation ("androidx.activity:activity-compose:1.8.0")
                implementation ("androidx.compose.ui:ui:1.5.4")
                implementation ("androidx.compose.foundation:foundation:1.5.4")
           //     implementation ("com.soywiz.korlibs.korge:korge-android-compose:5.4.0")
                implementation(libs.com.soywiz.korge.korge2)
                implementation(libs.soywiz.korge.android)
//                implementation(libs.github.korge)
//                implementation(libs.github.korge.android)
                implementation (libs.androidx.activity.compose.v180)
                implementation (libs.androidx.ui.v154)
                implementation (libs.androidx.foundation.v154)
          //      implementation (libs.soywiz.korge.core)
                // AndroidX libraries
                implementation(libs.androidx.appcompat)
                implementation("com.google.android.material:material:1.11.0")
                implementation("androidx.constraintlayout:constraintlayout:2.2.1")

                // Compose
                implementation(libs.androidx.activity.compose.v182)
                implementation(libs.androidx.runtime)
            }
        }
    }
}

android {
    namespace = "com.example.subwysurferclone.shared"
    compileSdk = 35

    defaultConfig {
        minSdk = 21
        targetSdk = 35
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    dataBinding {
        enable = true
    }
}

dependencies {
    // Consolidated KorGE Dependencies
    implementation (libs.androidx.activity.compose.v180)
    implementation (libs.androidx.ui.v154)
    implementation (libs.androidx.foundation.v154)
 //   implementation (libs.com.soywiz.korlibs.korge.korge.android.compose)
    implementation(libs.com.soywiz.korge.korge2)
    implementation(libs.soywiz.korge.android)
    // Android libraries
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.appcompat)
  //  implementation(libs.core)
    implementation(libs.androidx.activity.ktx)
    implementation (libs.androidx.activity.compose.v180)
    implementation (libs.androidx.ui.v154)
    implementation (libs.androidx.foundation.v154)
    // Compose Runtime
  //  implementation (libs.soywiz.korge.core)
    implementation(libs.androidx.runtime)
    implementation(libs.androidx.constraintlayout.compose.android)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android.v173)

    // Android Core Dependencies
    implementation(libs.androidx.core.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.ktx)

    // Material Design
    implementation(libs.com.google.android.material.material)
    implementation(libs.kotlin.stdlib.v190)

    // ConstraintLayout
    implementation(libs.androidx.constraintlayout.constraintlayout)

//    implementation(libs.github.korge)
//    implementation(libs.github.korge.android)
}


