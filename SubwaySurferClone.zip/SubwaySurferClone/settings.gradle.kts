// Gradle Settings Configuration for Subway Surfers Clone Project
pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
        maven("https://maven.pkg.jetbrains.space/korge/p/korge/dev")
        maven("https://jitpack.io")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        pluginManagement {
            repositories {
                google()
                mavenCentral()
                gradlePluginPortal()
                maven("https://maven.pkg.jetbrains.space/korge/p/korge/dev")
                maven("https://jitpack.io")
                maven("https://plugins.gradle.org/m2/")
            }
        }

        dependencyResolutionManagement {
            repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
            repositories {
                google()
                mavenCentral()
                maven("https://maven.pkg.jetbrains.space/korge/p/korge/dev")
                maven("https://jitpack.io")
                maven("https://plugins.gradle.org/m2/")
            }
        }
    }
}

// Project name
rootProject.name = "SubwaySurferClone"

// Included modules
include(":shared")
include(":androidApp")